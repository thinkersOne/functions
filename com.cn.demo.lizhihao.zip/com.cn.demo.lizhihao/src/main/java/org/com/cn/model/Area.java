package org.com.cn.model;

public class Area {
    private Number x1;
    private Number y1;
    private Number x2;
    private Number y2;
    private Number page;

    public Number getX1() {
        return x1;
    }

    public void setX1(Number x1) {
        this.x1 = x1;
    }

    public Number getY1() {
        return y1;
    }

    public void setY1(Number y1) {
        this.y1 = y1;
    }

    public Number getX2() {
        return x2;
    }

    public void setX2(Number x2) {
        this.x2 = x2;
    }

    public Number getY2() {
        return y2;
    }

    public void setY2(Number y2) {
        this.y2 = y2;
    }

    public Number getPage() {
        return page;
    }

    public void setPage(Number page) {
        this.page = page;
    }
}
