package org.com.cn.fangxinqian;

import com.alibaba.fastjson.JSONObject;
import org.junit.jupiter.api.Test;

/**
 * 为您提供从合同上传、签署、证书等数据
 */
public class SignOnline {

    @Test
    public void testGenerateContainer () {
//        JksCore jksCore = new JksCore();
//        GenerateJksContainer generateJksContainer = new GenerateJksContainer();
//        GenerateJksContainerRequire generateJksContainerRequire = new GenerateJksContainerRequire();
//        generateJksContainerRequire.setSavePath(this.jksSavePath)
//                .setKeyStoreName("demo.ks")
//                .setKeyStorePd("123456")//container password
//                .setFcAlias("first-cert")//alias of first certificate
//                .setFcPassword("123123")//password of first certificate
//                .setFcName("liumapp")
//                .setFcCountry("CN")
//                .setFcProvince("ZJ")
//                .setFcCity("Hangzhou");
//        JSONObject result = jksCore.doJob(generateJksContainer, generateJksContainerRequire);
    }

}
